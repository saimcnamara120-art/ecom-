"""ASGI entry point for ecommerce_marketplace."""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault(
    'DJANGO_SETTINGS_MODULE',
    'ecommerce_marketplace.settings'
)

application = get_asgi_application()
